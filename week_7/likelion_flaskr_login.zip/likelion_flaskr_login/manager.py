from apps import manager

manager.run()